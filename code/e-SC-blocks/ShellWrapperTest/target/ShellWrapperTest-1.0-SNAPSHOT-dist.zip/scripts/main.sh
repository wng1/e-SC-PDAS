#!/bin/bash

/usr/bin/printenv

ls
